This is Gmsh, an automatic three-dimensional finite element mesh generator with
built-in pre- and post-processing facilities.

Gmsh is distributed under the terms of the GNU General Public License. See the
LICENSE.txt and CREDITS.txt files for more information.

The tutorials/ directory contains the Gmsh tutorials from the reference manual
(https://gmsh.info/doc/texinfo/). The examples/ directory contains additional
examples.
